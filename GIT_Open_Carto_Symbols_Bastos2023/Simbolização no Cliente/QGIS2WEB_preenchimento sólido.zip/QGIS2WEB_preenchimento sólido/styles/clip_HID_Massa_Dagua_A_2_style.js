var size = 0;
var placement = 'point';

var style_clip_HID_Massa_Dagua_A_2 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = ""
    var labelText = "";
    size = 0;
    var labelFont = "italic bold 15.0px \'MS Shell Dlg 2\', Century Gothic";
    var labelFill = "#045da3";
    var bufferColor = "#FFFFFF";
    var bufferWidth = 1;
    var textAlign = "center";
    var offsetX = 8;
    var offsetY = 3;
    var placement = 'point';
    if (feature.get("NOME") !== null) {
        labelText = String(feature.get("NOME"));
    }
    var style = [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: '#045da3', lineDash: null, lineCap: 'butt', lineJoin: 'miter', width: 0}),fill: new ol.style.Fill({color: '#91d1f5'}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];

    return style;
};
