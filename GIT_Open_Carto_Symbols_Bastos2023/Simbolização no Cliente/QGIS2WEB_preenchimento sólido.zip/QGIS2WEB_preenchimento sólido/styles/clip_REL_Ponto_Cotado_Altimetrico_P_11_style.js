var size = 0;
var placement = 'point';

var style_clip_REL_Ponto_Cotado_Altimetrico_P_11 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = ""
    var labelText = "";
    size = 0;
    var labelFont = "bold italic 8px \'Open Sans\', Century Gothic";
    var labelFill = "#705714";
    var bufferColor = "#FFFFFF";
    var bufferWidth = 1;
    var placement = 'point';
    if (feature.get("COTA") !== null) {
        labelText = String(feature.get("COTA"));
    }
    var style3 = [ new ol.style.Style({
        image: new ol.style.RegularShape({radius: 3 + size,
                                          points: 4,
                                          radius2: 0,
                                          angle: Math.PI / 4,
                                          stroke: new ol.style.Stroke({color: '#705714', lineDash: null, lineCap: 'square', lineJoin: 'miter', width: 1}),
                                          fill: new ol.style.Fill({color: '#705714'})}),
        text: createTextStyle3(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];

    return style3;
};
var createTextStyle3 = function(feature, resolution, labelText, labelFont,
                               labelFill, placement, bufferColor,
                               bufferWidth) {

    if (feature.hide || !labelText) {
        return; 
    } 

    if (bufferWidth == 0) {
        var bufferStyle = null;
    } else {
        var bufferStyle = new ol.style.Stroke({
            color: bufferColor,
            width: bufferWidth
        })
    }
    
    var textStyle3 = new ol.style.Text({
        font: labelFont,
        text: labelText,
        textAlign: "left",
        offsetY: 8,
        placement: placement,
        fill: new ol.style.Fill({
          color: labelFill
        }),
        stroke: bufferStyle
    });
    return textStyle3;
};