var size = 0;
var placement = 'point';

var style_clip_ECO_Ext_Mineral_P_6 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = ""
    var labelText = "";
    size = 0;
    var labelFont = "9.0px \'MS Shell Dlg 2\', Century Gothic";
    var labelFill = "#000000";
    var bufferColor = "#FFFFFF";
    var bufferWidth = 2;
    var textAlign = "center";
    var offsetX = 8;
    var offsetY = 3;
    var placement = 'point';
    if (feature.get("NOME") !== null) {
        labelText = String(feature.get("NOME"));
    }
    var style = [ new ol.style.Style({
        image: new ol.style.Icon({
                  imgSize: [580, 580],
                  scale: 0.02,
                  anchor: [4, 4],
                  anchorXUnits: "pixels",
                  anchorYUnits: "pixels",
                  rotation: 0.0,
                  src: "styles/poi_mine.svg"
            }),
        text: createTextStyle_ext(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];

    return style;
};
var createTextStyle_ext = function(feature, resolution, labelText, labelFont,
                               labelFill, placement, bufferColor,
                               bufferWidth) {

    if (feature.hide || !labelText) {
        return; 
    } 

    if (bufferWidth == 0) {
        var bufferStyle = null;
    } else {
        var bufferStyle = new ol.style.Stroke({
            color: bufferColor,
            width: bufferWidth
        })
    }
    
    var textStyle_ext = new ol.style.Text({
        font: labelFont,
        text: labelText,
        textAlign: "center",
        offsetY: 20,
        placement: placement,
        fill: new ol.style.Fill({
          color: labelFill
        }),
        stroke: bufferStyle
    });
    return textStyle_ext;
};