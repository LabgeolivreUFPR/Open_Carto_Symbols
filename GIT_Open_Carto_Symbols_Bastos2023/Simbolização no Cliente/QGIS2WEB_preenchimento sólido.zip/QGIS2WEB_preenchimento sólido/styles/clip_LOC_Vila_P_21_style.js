var size = 0;
var placement = 'point';

var style_clip_LOC_Vila_P_21 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = ""
    var labelText = "";
    size = 0;
    var labelFont = "18px \'Times New Roman\', sans-serif";
    var labelFill = "#000000";
    var bufferColor = "#ffffff";
    var bufferWidth = 1;
    var textAlign = "center";
    var offsetX = 8;
    var offsetY = 20;
    var placement = 'point';
    if (feature.get("NOME") !== null) {
        labelText = String(feature.get("NOME"));
    }
	var style = [ new ol.style.Style({
        image: new ol.style.Circle({radius: 0 + size,
            stroke: new ol.style.Stroke({color: '#000000', lineDash: null, lineCap: 'butt', lineJoin: 'miter', width: 1}), fill: new ol.style.Fill({color: '#ffffff'})}),
        text: createTextStyle_vila(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
     })];

    return style;
};

var createTextStyle_vila = function(feature, resolution, labelText, labelFont,
                               labelFill, placement, bufferColor,
                               bufferWidth) {

    if (feature.hide || !labelText) {
        return; 
    } 

    if (bufferWidth == 0) {
        var bufferStyle = null;
    } else {
        var bufferStyle = new ol.style.Stroke({
            color: bufferColor,
            width: bufferWidth
        })
    }
    
    var textStyle_vila = new ol.style.Text({
        font: labelFont,
        text: labelText,
        textAlign: "center",
        offsetY: 20,
        placement: placement,
        fill: new ol.style.Fill({
          color: labelFill
        }),
        stroke: bufferStyle
    });
    return textStyle_vila;
};