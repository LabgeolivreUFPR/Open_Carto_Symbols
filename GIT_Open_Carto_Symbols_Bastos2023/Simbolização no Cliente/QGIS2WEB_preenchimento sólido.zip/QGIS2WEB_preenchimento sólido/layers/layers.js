ol.proj.proj4.register(proj4);
ol.proj.get("EPSG:4674").setExtent([-43.125000, -23.000000, -42.875000, -22.750000]);
var wms_layers = [];

var format_clip_REL_Rocha_A_0 = new ol.format.GeoJSON();
var features_clip_REL_Rocha_A_0 = format_clip_REL_Rocha_A_0.readFeatures(json_clip_REL_Rocha_A_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_REL_Rocha_A_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_REL_Rocha_A_0.addFeatures(features_clip_REL_Rocha_A_0);
var lyr_clip_REL_Rocha_A_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_REL_Rocha_A_0, 
                style: style_clip_REL_Rocha_A_0,
                interactive: true,
                title: '<img src="styles/legend/clip_REL_Rocha_A_0.png" /> clip_REL_Rocha_A'
            });
var format_clip_VEG_Veg_Restinga_A_9 = new ol.format.GeoJSON();
var features_clip_VEG_Veg_Restinga_A_9 = format_clip_VEG_Veg_Restinga_A_9.readFeatures(json_clip_VEG_Veg_Restinga_A_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_VEG_Veg_Restinga_A_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_VEG_Veg_Restinga_A_9.addFeatures(features_clip_VEG_Veg_Restinga_A_9);
var lyr_clip_VEG_Veg_Restinga_A_9 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_VEG_Veg_Restinga_A_9, 
                style: style_clip_VEG_Veg_Restinga_A_9,
                interactive: true,
                title: '<img src="styles/legend/clip_VEG_Veg_Restinga_A_9.png" /> clip_VEG_Veg_Restinga_A'
            });
var format_clip_ADM_Posto_Pol_Rod_P_14 = new ol.format.GeoJSON();
var features_clip_ADM_Posto_Pol_Rod_P_14 = format_clip_ADM_Posto_Pol_Rod_P_14.readFeatures(json_clip_ADM_Posto_Pol_Rod_P_14, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_ADM_Posto_Pol_Rod_P_14 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ADM_Posto_Pol_Rod_P_14.addFeatures(features_clip_ADM_Posto_Pol_Rod_P_14);
var lyr_clip_ADM_Posto_Pol_Rod_P_14 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_ADM_Posto_Pol_Rod_P_14, 
                style: style_clip_ADM_Posto_Pol_Rod_P_14,
                interactive: true,
                title: '<img src="styles/legend/clip_ADM_Posto_Pol_Rod_P_14.png" /> clip_ADM_Posto_Pol_Rod_P'
            });
var format_clip_EDU_Campo_Quadra_P_12 = new ol.format.GeoJSON();
var features_clip_EDU_Campo_Quadra_P_12 = format_clip_EDU_Campo_Quadra_P_12.readFeatures(json_clip_EDU_Campo_Quadra_P_12, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_EDU_Campo_Quadra_P_12 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_EDU_Campo_Quadra_P_12.addFeatures(features_clip_EDU_Campo_Quadra_P_12);
var lyr_clip_EDU_Campo_Quadra_P_12 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_EDU_Campo_Quadra_P_12, 
                style: style_clip_EDU_Campo_Quadra_P_12,
                interactive: true,
                title: '<img src="styles/legend/clip_EDU_Campo_Quadra_P_12.png" /> clip_EDU_Campo_Quadra_P'
            });
var format_clip_VEG_Veg_Cultivada_A_0 = new ol.format.GeoJSON();
var features_clip_VEG_Veg_Cultivada_A_0 = format_clip_VEG_Veg_Cultivada_A_0.readFeatures(json_clip_VEG_Veg_Cultivada_A_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_VEG_Veg_Cultivada_A_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_VEG_Veg_Cultivada_A_0.addFeatures(features_clip_VEG_Veg_Cultivada_A_0);
var lyr_clip_VEG_Veg_Cultivada_A_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_VEG_Veg_Cultivada_A_0, 
                style: style_clip_VEG_Veg_Cultivada_A_0,
                interactive: true,
                title: '<img src="styles/legend/clip_VEG_Veg_Cultivada_A_0.png" /> clip_VEG_Veg_Cultivada_A'
            });
var format_clip_REL_Elemento_Fisiografico_Natural_A_0 = new ol.format.GeoJSON();
var features_clip_REL_Elemento_Fisiografico_Natural_A_0 = format_clip_REL_Elemento_Fisiografico_Natural_A_0.readFeatures(json_clip_REL_Elemento_Fisiografico_Natural_A_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_REL_Elemento_Fisiografico_Natural_A_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_REL_Elemento_Fisiografico_Natural_A_0.addFeatures(features_clip_REL_Elemento_Fisiografico_Natural_A_0);
var lyr_clip_REL_Elemento_Fisiografico_Natural_A_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_REL_Elemento_Fisiografico_Natural_A_0, 
                style: style_clip_REL_Elemento_Fisiografico_Natural_A_0,
                interactive: true,
                title: '<img src="styles/legend/clip_REL_Elemento_Fisiografico_Natural_A_0.png" /> clip_REL_Elemento_Fisiografico_Natural_A'
            });
var format_clip_HID_Terreno_Sujeito_Inundacao_A_0 = new ol.format.GeoJSON();
var features_clip_HID_Terreno_Sujeito_Inundacao_A_0 = format_clip_HID_Terreno_Sujeito_Inundacao_A_0.readFeatures(json_clip_HID_Terreno_Sujeito_Inundacao_A_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_HID_Terreno_Sujeito_Inundacao_A_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_HID_Terreno_Sujeito_Inundacao_A_0.addFeatures(features_clip_HID_Terreno_Sujeito_Inundacao_A_0);
var lyr_clip_HID_Terreno_Sujeito_Inundacao_A_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_HID_Terreno_Sujeito_Inundacao_A_0, 
                style: style_clip_HID_Terreno_Sujeito_Inundacao_A_0,
                interactive: true,
                title: '<img src="styles/legend/clip_HID_Terreno_Sujeito_Inundacao_A_0.png" /> clip_HID_Terreno_Sujeito_Inundacao_A'
            });
var format_clip_HID_Ilha_A_8 = new ol.format.GeoJSON();
var features_clip_HID_Ilha_A_8 = format_clip_HID_Ilha_A_8.readFeatures(json_clip_HID_Ilha_A_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_HID_Ilha_A_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_HID_Ilha_A_8.addFeatures(features_clip_HID_Ilha_A_8);
var lyr_clip_HID_Ilha_A_8 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_HID_Ilha_A_8, 
                style: style_clip_HID_Ilha_A_8,
                interactive: true,
                title: '<img src="styles/legend/clip_HID_Ilha_A_8.png" /> clip_HID_Ilha_A'
            });
var format_clip_TRA_Trecho_Ferroviario_L_10 = new ol.format.GeoJSON();
var features_clip_TRA_Trecho_Ferroviario_L_10 = format_clip_TRA_Trecho_Ferroviario_L_10.readFeatures(json_clip_TRA_Trecho_Ferroviario_L_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_TRA_Trecho_Ferroviario_L_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_TRA_Trecho_Ferroviario_L_10.addFeatures(features_clip_TRA_Trecho_Ferroviario_L_10);
var lyr_clip_TRA_Trecho_Ferroviario_L_10 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_TRA_Trecho_Ferroviario_L_10, 
                style: style_clip_TRA_Trecho_Ferroviario_L_10,
                interactive: true,
                title: '<img src="styles/legend/clip_TRA_Trecho_Ferroviario_L_10.png" /> clip_TRA_Trecho_Ferroviario_L'
            });
var format_clip_VEG_Brejo_Pantano_A_3 = new ol.format.GeoJSON();
var features_clip_VEG_Brejo_Pantano_A_3 = format_clip_VEG_Brejo_Pantano_A_3.readFeatures(json_clip_VEG_Brejo_Pantano_A_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_VEG_Brejo_Pantano_A_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_VEG_Brejo_Pantano_A_3.addFeatures(features_clip_VEG_Brejo_Pantano_A_3);
var lyr_clip_VEG_Brejo_Pantano_A_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_VEG_Brejo_Pantano_A_3, 
                style: style_clip_VEG_Brejo_Pantano_A_3,
                interactive: true,
                title: '<img src="styles/legend/clip_VEG_Brejo_Pantano_A_3.png" /> clip_VEG_Brejo_Pantano_A'
            });
var format_clip_VEG_Campo_A_2 = new ol.format.GeoJSON();
var features_clip_VEG_Campo_A_2 = format_clip_VEG_Campo_A_2.readFeatures(json_clip_VEG_Campo_A_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_VEG_Campo_A_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_VEG_Campo_A_2.addFeatures(features_clip_VEG_Campo_A_2);
var lyr_clip_VEG_Campo_A_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_VEG_Campo_A_2, 
                style: style_clip_VEG_Campo_A_2,
                interactive: true,
                title: '<img src="styles/legend/clip_VEG_Campo_A_2.png" /> clip_VEG_Campo_A'
            });
var format_clip_VEG_Mangue_A_1 = new ol.format.GeoJSON();
var features_clip_VEG_Mangue_A_1 = format_clip_VEG_Mangue_A_1.readFeatures(json_clip_VEG_Mangue_A_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_VEG_Mangue_A_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_VEG_Mangue_A_1.addFeatures(features_clip_VEG_Mangue_A_1);
var lyr_clip_VEG_Mangue_A_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_VEG_Mangue_A_1, 
                style: style_clip_VEG_Mangue_A_1,
                interactive: true,
                title: '<img src="styles/legend/clip_VEG_Mangue_A_1.png" /> clip_VEG_Mangue_A'
            });
var format_clip_ADM_Edif_Pub_Militar_P_15 = new ol.format.GeoJSON();
var features_clip_ADM_Edif_Pub_Militar_P_15 = format_clip_ADM_Edif_Pub_Militar_P_15.readFeatures(json_clip_ADM_Edif_Pub_Militar_P_15, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_ADM_Edif_Pub_Militar_P_15 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ADM_Edif_Pub_Militar_P_15.addFeatures(features_clip_ADM_Edif_Pub_Militar_P_15);
var lyr_clip_ADM_Edif_Pub_Militar_P_15 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_ADM_Edif_Pub_Militar_P_15, 
                style: style_clip_ADM_Edif_Pub_Militar_P_15,
                interactive: true,
                title: '<img src="styles/legend/clip_ADM_Edif_Pub_Militar_P_15.png" /> clip_ADM_Edif_Pub_Militar_P'
            });
var format_clip_ASB_Cemiterio_P_13 = new ol.format.GeoJSON();
var features_clip_ASB_Cemiterio_P_13 = format_clip_ASB_Cemiterio_P_13.readFeatures(json_clip_ASB_Cemiterio_P_13, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_ASB_Cemiterio_P_13 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ASB_Cemiterio_P_13.addFeatures(features_clip_ASB_Cemiterio_P_13);
var lyr_clip_ASB_Cemiterio_P_13 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_ASB_Cemiterio_P_13, 
                style: style_clip_ASB_Cemiterio_P_13,
                interactive: true,
                title: '<img src="styles/legend/clip_ASB_Cemiterio_P_13.png" /> clip_ASB_Cemiterio_P'
            });
var format_clip_EDU_Edif_Ensino_P_18 = new ol.format.GeoJSON();
var features_clip_EDU_Edif_Ensino_P_18 = format_clip_EDU_Edif_Ensino_P_18.readFeatures(json_clip_EDU_Edif_Ensino_P_18, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_EDU_Edif_Ensino_P_18 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_EDU_Edif_Ensino_P_18.addFeatures(features_clip_EDU_Edif_Ensino_P_18);
var lyr_clip_EDU_Edif_Ensino_P_18 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_EDU_Edif_Ensino_P_18, 
                style: style_clip_EDU_Edif_Ensino_P_18,
                interactive: true,
                title: '<img src="styles/legend/clip_EDU_Edif_Ensino_P_18.png" /> clip_EDU_Edif_Ensino_P'
            });
var format_clip_LOC_Nome_Local_P_19 = new ol.format.GeoJSON();
var features_clip_LOC_Nome_Local_P_19 = format_clip_LOC_Nome_Local_P_19.readFeatures(json_clip_LOC_Nome_Local_P_19, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_LOC_Nome_Local_P_19 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_LOC_Nome_Local_P_19.addFeatures(features_clip_LOC_Nome_Local_P_19);
var lyr_clip_LOC_Nome_Local_P_19 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_LOC_Nome_Local_P_19, 
                style: style_clip_LOC_Nome_Local_P_19,
                interactive: true,
                title: '<img src="styles/legend/clip_LOC_Nome_Local_P_19.png" /> clip_LOC_Nome_Local_P'
            });
var format_clip_HID_Trecho_Massa_Dagua_A_7 = new ol.format.GeoJSON();
var features_clip_HID_Trecho_Massa_Dagua_A_7 = format_clip_HID_Trecho_Massa_Dagua_A_7.readFeatures(json_clip_HID_Trecho_Massa_Dagua_A_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_HID_Trecho_Massa_Dagua_A_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_HID_Trecho_Massa_Dagua_A_7.addFeatures(features_clip_HID_Trecho_Massa_Dagua_A_7);
var lyr_clip_HID_Trecho_Massa_Dagua_A_7 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_HID_Trecho_Massa_Dagua_A_7, 
                style: style_clip_HID_Trecho_Massa_Dagua_A_7,
                interactive: true,
                title: '<img src="styles/legend/clip_HID_Trecho_Massa_Dagua_A_7.png" /> clip_HID_Trecho_Massa_Dagua_A'
            });
var format_clip_LOC_Vila_P_21 = new ol.format.GeoJSON();
var features_clip_LOC_Vila_P_21 = format_clip_LOC_Vila_P_21.readFeatures(json_clip_LOC_Vila_P_21, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_LOC_Vila_P_21 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_LOC_Vila_P_21.addFeatures(features_clip_LOC_Vila_P_21);
var lyr_clip_LOC_Vila_P_21 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_LOC_Vila_P_21, 
                style: style_clip_LOC_Vila_P_21,
                interactive: true,
                title: '<img src="styles/legend/clip_LOC_Vila_P_21.png" /> clip_LOC_Aglomerado_Rural_Isolado_P'
            });
var format_clip_VEG_Floresta_A_0 = new ol.format.GeoJSON();
var features_clip_VEG_Floresta_A_0 = format_clip_VEG_Floresta_A_0.readFeatures(json_clip_VEG_Floresta_A_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_VEG_Floresta_A_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_VEG_Floresta_A_0.addFeatures(features_clip_VEG_Floresta_A_0);
var lyr_clip_VEG_Floresta_A_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_VEG_Floresta_A_0, 
                style: style_clip_VEG_Floresta_A_0,
                interactive: true,
                title: '<img src="styles/legend/clip_VEG_Floresta_A_0.png" /> clip_VEG_Floresta_A'
            });
var format_clip_LOC_Area_Edificada_A_6 = new ol.format.GeoJSON();
var features_clip_LOC_Area_Edificada_A_6 = format_clip_LOC_Area_Edificada_A_6.readFeatures(json_clip_LOC_Area_Edificada_A_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_LOC_Area_Edificada_A_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_LOC_Area_Edificada_A_6.addFeatures(features_clip_LOC_Area_Edificada_A_6);
var lyr_clip_LOC_Area_Edificada_A_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_LOC_Area_Edificada_A_6, 
                style: style_clip_LOC_Area_Edificada_A_6,
                interactive: true,
                title: '<img src="styles/legend/clip_LOC_Area_Edificada_A_6.png" /> clip_LOC_Area_Edificada_A'
            });
var format_clip_LIM_Limite_Politico_Administrativo_L_1 = new ol.format.GeoJSON();
var features_clip_LIM_Limite_Politico_Administrativo_L_1 = format_clip_LIM_Limite_Politico_Administrativo_L_1.readFeatures(json_clip_LIM_Limite_Politico_Administrativo_L_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_LIM_Limite_Politico_Administrativo_L_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_LIM_Limite_Politico_Administrativo_L_1.addFeatures(features_clip_LIM_Limite_Politico_Administrativo_L_1);
var lyr_clip_LIM_Limite_Politico_Administrativo_L_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_LIM_Limite_Politico_Administrativo_L_1, 
                style: style_clip_LIM_Limite_Politico_Administrativo_L_1,
                interactive: true,
                title: '<img src="styles/legend/clip_LIM_Limite_Politico_Administrativo_L_1.png" /> clip_LIM_Limite_Politico_Administrativo_L'
            });
var format_clip_HID_Massa_Dagua_A_2 = new ol.format.GeoJSON();
var features_clip_HID_Massa_Dagua_A_2 = format_clip_HID_Massa_Dagua_A_2.readFeatures(json_clip_HID_Massa_Dagua_A_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_HID_Massa_Dagua_A_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_HID_Massa_Dagua_A_2.addFeatures(features_clip_HID_Massa_Dagua_A_2);
var lyr_clip_HID_Massa_Dagua_A_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_HID_Massa_Dagua_A_2, 
                style: style_clip_HID_Massa_Dagua_A_2,
                interactive: true,
                title: '<img src="styles/legend/clip_HID_Massa_Dagua_A_2.png" /> clip_HID_Massa_Dagua_A'
            });
var format_clip_HID_Trecho_Drenagem_L_3 = new ol.format.GeoJSON();
var features_clip_HID_Trecho_Drenagem_L_3 = format_clip_HID_Trecho_Drenagem_L_3.readFeatures(json_clip_HID_Trecho_Drenagem_L_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_HID_Trecho_Drenagem_L_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_HID_Trecho_Drenagem_L_3.addFeatures(features_clip_HID_Trecho_Drenagem_L_3);
var lyr_clip_HID_Trecho_Drenagem_L_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_HID_Trecho_Drenagem_L_3, 
                style: style_clip_HID_Trecho_Drenagem_L_3,
                interactive: true,
    title: 'clip_HID_Trecho_Drenagem_L<br />\
    <img src="styles/legend/clip_HID_Trecho_Drenagem_L_3_0.png" /> Permanente<br />\
    <img src="styles/legend/clip_HID_Trecho_Drenagem_L_3_1.png" /> Temporário<br />'
        });
var format_clip_LOC_Cidade_P_4 = new ol.format.GeoJSON();
var features_clip_LOC_Cidade_P_4 = format_clip_LOC_Cidade_P_4.readFeatures(json_clip_LOC_Cidade_P_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_LOC_Cidade_P_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_LOC_Cidade_P_4.addFeatures(features_clip_LOC_Cidade_P_4);
var lyr_clip_LOC_Cidade_P_4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_LOC_Cidade_P_4, 
                style: style_clip_LOC_Cidade_P_4,
                interactive: true,
                title: '<img src="styles/legend/clip_LOC_Cidade_P_4.png" /> clip_LOC_Cidade_P'
            });
var format_clip_ASB_Area_Abast_Agua_A_5 = new ol.format.GeoJSON();
var features_clip_ASB_Area_Abast_Agua_A_5 = format_clip_ASB_Area_Abast_Agua_A_5.readFeatures(json_clip_ASB_Area_Abast_Agua_A_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_ASB_Area_Abast_Agua_A_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ASB_Area_Abast_Agua_A_5.addFeatures(features_clip_ASB_Area_Abast_Agua_A_5);
var lyr_clip_ASB_Area_Abast_Agua_A_5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_ASB_Area_Abast_Agua_A_5, 
                style: style_clip_ASB_Area_Abast_Agua_A_5,
                interactive: true,
                title: '<img src="styles/legend/clip_ASB_Area_Abast_Agua_A_5.png" /> clip_ASB_Area_Abast_Agua_A'
            });
var format_clip_ECO_Ext_Mineral_P_6 = new ol.format.GeoJSON();
var features_clip_ECO_Ext_Mineral_P_6 = format_clip_ECO_Ext_Mineral_P_6.readFeatures(json_clip_ECO_Ext_Mineral_P_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_ECO_Ext_Mineral_P_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ECO_Ext_Mineral_P_6.addFeatures(features_clip_ECO_Ext_Mineral_P_6);
var lyr_clip_ECO_Ext_Mineral_P_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_ECO_Ext_Mineral_P_6, 
                style: style_clip_ECO_Ext_Mineral_P_6,
                interactive: true,
                title: '<img src="styles/legend/clip_ECO_Ext_Mineral_P_6.png" /> clip_ECO_Ext_Mineral_P'
            });
var format_clip_ENC_Area_Energia_Eletrica_A_7 = new ol.format.GeoJSON();
var features_clip_ENC_Area_Energia_Eletrica_A_7 = format_clip_ENC_Area_Energia_Eletrica_A_7.readFeatures(json_clip_ENC_Area_Energia_Eletrica_A_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_ENC_Area_Energia_Eletrica_A_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ENC_Area_Energia_Eletrica_A_7.addFeatures(features_clip_ENC_Area_Energia_Eletrica_A_7);
var lyr_clip_ENC_Area_Energia_Eletrica_A_7 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_ENC_Area_Energia_Eletrica_A_7, 
                style: style_clip_ENC_Area_Energia_Eletrica_A_7,
                interactive: true,
                title: '<img src="styles/legend/clip_ENC_Area_Energia_Eletrica_A_7.png" /> clip_ENC_Area_Energia_Eletrica_A'
            });
var format_clip_ENC_Trecho_Energia_L_8 = new ol.format.GeoJSON();
var features_clip_ENC_Trecho_Energia_L_8 = format_clip_ENC_Trecho_Energia_L_8.readFeatures(json_clip_ENC_Trecho_Energia_L_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_ENC_Trecho_Energia_L_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ENC_Trecho_Energia_L_8.addFeatures(features_clip_ENC_Trecho_Energia_L_8);
var lyr_clip_ENC_Trecho_Energia_L_8 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_ENC_Trecho_Energia_L_8, 
                style: style_clip_ENC_Trecho_Energia_L_8,
                interactive: true,
                title: '<img src="styles/legend/clip_ENC_Trecho_Energia_L_8.png" /> clip_ENC_Trecho_Energia_L'
            });
var format_clip_REL_Curva_Nivel_L_9 = new ol.format.GeoJSON();
var features_clip_REL_Curva_Nivel_L_9 = format_clip_REL_Curva_Nivel_L_9.readFeatures(json_clip_REL_Curva_Nivel_L_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_REL_Curva_Nivel_L_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_REL_Curva_Nivel_L_9.addFeatures(features_clip_REL_Curva_Nivel_L_9);
var lyr_clip_REL_Curva_Nivel_L_9 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_REL_Curva_Nivel_L_9, 
                style: style_clip_REL_Curva_Nivel_L_9,
                interactive: true,
    title: 'clip_REL_Curva_Nivel_L<br />\
    <img src="styles/legend/clip_REL_Curva_Nivel_L_9_0.png" /> Mestra<br />\
    <img src="styles/legend/clip_REL_Curva_Nivel_L_9_1.png" /> Normal<br />'
        });
var format_clip_REL_Elemento_Fisiografico_Natural_P_10 = new ol.format.GeoJSON();
var features_clip_REL_Elemento_Fisiografico_Natural_P_10 = format_clip_REL_Elemento_Fisiografico_Natural_P_10.readFeatures(json_clip_REL_Elemento_Fisiografico_Natural_P_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_REL_Elemento_Fisiografico_Natural_P_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_REL_Elemento_Fisiografico_Natural_P_10.addFeatures(features_clip_REL_Elemento_Fisiografico_Natural_P_10);
var lyr_clip_REL_Elemento_Fisiografico_Natural_P_10 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_REL_Elemento_Fisiografico_Natural_P_10, 
                style: style_clip_REL_Elemento_Fisiografico_Natural_P_10,
                interactive: true,
                title: '<img src="styles/legend/clip_REL_Elemento_Fisiografico_Natural_P_10.png" /> clip_REL_Elemento_Fisiografico_Natural_P'
            });
var format_clip_REL_Ponto_Cotado_Altimetrico_P_11 = new ol.format.GeoJSON();
var features_clip_REL_Ponto_Cotado_Altimetrico_P_11 = format_clip_REL_Ponto_Cotado_Altimetrico_P_11.readFeatures(json_clip_REL_Ponto_Cotado_Altimetrico_P_11, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_REL_Ponto_Cotado_Altimetrico_P_11 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_REL_Ponto_Cotado_Altimetrico_P_11.addFeatures(features_clip_REL_Ponto_Cotado_Altimetrico_P_11);
var lyr_clip_REL_Ponto_Cotado_Altimetrico_P_11 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_REL_Ponto_Cotado_Altimetrico_P_11, 
                style: style_clip_REL_Ponto_Cotado_Altimetrico_P_11,
                interactive: true,
                title: '<img src="styles/legend/clip_REL_Ponto_Cotado_Altimetrico_P_11.png" /> clip_REL_Ponto_Cotado_Altimetrico_P'
            });
var format_clip_TRA_Arruamento_L_12 = new ol.format.GeoJSON();
var features_clip_TRA_Arruamento_L_12 = format_clip_TRA_Arruamento_L_12.readFeatures(json_clip_TRA_Arruamento_L_12, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_TRA_Arruamento_L_12 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_TRA_Arruamento_L_12.addFeatures(features_clip_TRA_Arruamento_L_12);
var lyr_clip_TRA_Arruamento_L_12 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_TRA_Arruamento_L_12, 
                style: style_clip_TRA_Arruamento_L_12,
                interactive: true,
                title: '<img src="styles/legend/clip_TRA_Arruamento_L_12.png" /> clip_TRA_Arruamento_L'
            });
var format_clip_TRA_Atracadouro_L_13 = new ol.format.GeoJSON();
var features_clip_TRA_Atracadouro_L_13 = format_clip_TRA_Atracadouro_L_13.readFeatures(json_clip_TRA_Atracadouro_L_13, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_TRA_Atracadouro_L_13 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_TRA_Atracadouro_L_13.addFeatures(features_clip_TRA_Atracadouro_L_13);
var lyr_clip_TRA_Atracadouro_L_13 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_TRA_Atracadouro_L_13, 
                style: style_clip_TRA_Atracadouro_L_13,
                interactive: true,
                title: '<img src="styles/legend/clip_TRA_Atracadouro_L_13.png" /> clip_TRA_Atracadouro_L'
            });
var format_clip_TRA_Ponte_L_14 = new ol.format.GeoJSON();
var features_clip_TRA_Ponte_L_14 = format_clip_TRA_Ponte_L_14.readFeatures(json_clip_TRA_Ponte_L_14, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_TRA_Ponte_L_14 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_TRA_Ponte_L_14.addFeatures(features_clip_TRA_Ponte_L_14);
var lyr_clip_TRA_Ponte_L_14 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_TRA_Ponte_L_14, 
                style: style_clip_TRA_Ponte_L_14,
                interactive: true,
                title: '<img src="styles/legend/clip_TRA_Ponte_L_14.png" /> clip_TRA_Ponte_L'
            });
var format_clip_TRA_Trecho_Rodoviario_L_15 = new ol.format.GeoJSON();
var features_clip_TRA_Trecho_Rodoviario_L_15 = format_clip_TRA_Trecho_Rodoviario_L_15.readFeatures(json_clip_TRA_Trecho_Rodoviario_L_15, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4674'});
var jsonSource_clip_TRA_Trecho_Rodoviario_L_15 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_TRA_Trecho_Rodoviario_L_15.addFeatures(features_clip_TRA_Trecho_Rodoviario_L_15);
var lyr_clip_TRA_Trecho_Rodoviario_L_15 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_clip_TRA_Trecho_Rodoviario_L_15, 
                style: style_clip_TRA_Trecho_Rodoviario_L_15,
                interactive: true,
    title: 'clip_TRA_Trecho_Rodoviario_L<br />\
    <img src="styles/legend/clip_TRA_Trecho_Rodoviario_L_15_0.png" /> Leito natural<br />\
    <img src="styles/legend/clip_TRA_Trecho_Rodoviario_L_15_1.png" /> Pavimentado<br />'
        });
lyr_clip_VEG_Floresta_A_0.setVisible(true);lyr_clip_VEG_Mangue_A_1.setVisible(true);lyr_clip_VEG_Campo_A_2.setVisible(true);lyr_clip_VEG_Brejo_Pantano_A_3.setVisible(true);lyr_clip_LIM_Limite_Politico_Administrativo_L_1.setVisible(true);lyr_clip_HID_Massa_Dagua_A_2.setVisible(true);lyr_clip_HID_Trecho_Drenagem_L_3.setVisible(true);lyr_clip_LOC_Cidade_P_4.setVisible(true);lyr_clip_ASB_Area_Abast_Agua_A_5.setVisible(true);lyr_clip_EDU_Edif_Ensino_P_18.setVisible(true);lyr_clip_ECO_Ext_Mineral_P_6.setVisible(true);lyr_clip_ENC_Area_Energia_Eletrica_A_7.setVisible(true);lyr_clip_ENC_Trecho_Energia_L_8.setVisible(true);lyr_clip_REL_Curva_Nivel_L_9.setVisible(true);lyr_clip_REL_Elemento_Fisiografico_Natural_P_10.setVisible(true);lyr_clip_REL_Ponto_Cotado_Altimetrico_P_11.setVisible(true);lyr_clip_TRA_Arruamento_L_12.setVisible(true);lyr_clip_TRA_Atracadouro_L_13.setVisible(true);lyr_clip_TRA_Ponte_L_14.setVisible(true);lyr_clip_TRA_Trecho_Rodoviario_L_15.setVisible(true);lyr_clip_LOC_Area_Edificada_A_6.setVisible(true);lyr_clip_LOC_Vila_P_21.setVisible(true);lyr_clip_HID_Trecho_Massa_Dagua_A_7.setVisible(true);lyr_clip_LOC_Nome_Local_P_19.setVisible(true);lyr_clip_ASB_Cemiterio_P_13.setVisible(true);lyr_clip_ADM_Edif_Pub_Militar_P_15.setVisible(true);lyr_clip_TRA_Trecho_Ferroviario_L_10.setVisible(true);lyr_clip_HID_Ilha_A_8.setVisible(true);lyr_clip_HID_Terreno_Sujeito_Inundacao_A_0.setVisible(true);lyr_clip_REL_Elemento_Fisiografico_Natural_A_0.setVisible(true);lyr_clip_VEG_Veg_Cultivada_A_0.setVisible(true);lyr_clip_EDU_Campo_Quadra_P_12.setVisible(true);lyr_clip_ADM_Posto_Pol_Rod_P_14.setVisible(true);lyr_clip_VEG_Veg_Restinga_A_9.setVisible(true);lyr_clip_REL_Rocha_A_0.setVisible(true);
var layersList = [lyr_clip_VEG_Veg_Cultivada_A_0,lyr_clip_VEG_Floresta_A_0,lyr_clip_VEG_Mangue_A_1,lyr_clip_VEG_Campo_A_2,lyr_clip_VEG_Brejo_Pantano_A_3,lyr_clip_VEG_Veg_Restinga_A_9,lyr_clip_HID_Terreno_Sujeito_Inundacao_A_0,lyr_clip_REL_Rocha_A_0,lyr_clip_LOC_Area_Edificada_A_6,lyr_clip_HID_Ilha_A_8,lyr_clip_REL_Elemento_Fisiografico_Natural_A_0,lyr_clip_LOC_Nome_Local_P_19,lyr_clip_ASB_Cemiterio_P_13,lyr_clip_LIM_Limite_Politico_Administrativo_L_1,lyr_clip_HID_Massa_Dagua_A_2,lyr_clip_HID_Trecho_Drenagem_L_3,lyr_clip_HID_Trecho_Massa_Dagua_A_7,lyr_clip_ASB_Area_Abast_Agua_A_5,lyr_clip_ECO_Ext_Mineral_P_6,lyr_clip_ENC_Area_Energia_Eletrica_A_7,lyr_clip_ENC_Trecho_Energia_L_8,lyr_clip_TRA_Trecho_Ferroviario_L_10,lyr_clip_REL_Curva_Nivel_L_9,lyr_clip_REL_Elemento_Fisiografico_Natural_P_10,lyr_clip_REL_Ponto_Cotado_Altimetrico_P_11,lyr_clip_TRA_Arruamento_L_12,lyr_clip_TRA_Atracadouro_L_13,lyr_clip_TRA_Ponte_L_14,lyr_clip_TRA_Trecho_Rodoviario_L_15,lyr_clip_LOC_Vila_P_21,lyr_clip_LOC_Cidade_P_4,lyr_clip_EDU_Edif_Ensino_P_18,lyr_clip_ADM_Posto_Pol_Rod_P_14,lyr_clip_ADM_Edif_Pub_Militar_P_15,lyr_clip_EDU_Campo_Quadra_P_12];
lyr_clip_REL_Rocha_A_0.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOROCHA': 'TIPOROCHA', });
lyr_clip_REL_Rocha_A_0.set('fieldImages', {'ID_OBJETO': '', 'NOME': '', 'NOMEABREV': '', 'GEOMETRIAA': '', 'TIPOROCHA': '', });
lyr_clip_REL_Rocha_A_0.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOROCHA': 'no label', });
lyr_clip_VEG_Veg_Restinga_A_9.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'ALTURAMEDI': 'ALTURAMEDI', 'CLASSIFICA': 'CLASSIFICA', 'DENSO': 'DENSO', });
lyr_clip_VEG_Veg_Restinga_A_9.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'ALTURAMEDI': 'TextEdit', 'CLASSIFICA': 'TextEdit', 'DENSO': 'TextEdit', });
lyr_clip_VEG_Veg_Restinga_A_9.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'ALTURAMEDI': 'no label', 'CLASSIFICA': 'no label', 'DENSO': 'no label', });
lyr_clip_ADM_Posto_Pol_Rod_P_14.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'SITUACAOFI': 'SITUACAOFI', 'OPERACIONA': 'OPERACIONA', 'TIPOPOSTOP': 'TIPOPOSTOP', });
lyr_clip_ADM_Posto_Pol_Rod_P_14.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'SITUACAOFI': 'TextEdit', 'OPERACIONA': 'TextEdit', 'TIPOPOSTOP': 'TextEdit', });
lyr_clip_ADM_Posto_Pol_Rod_P_14.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'SITUACAOFI': 'no label', 'OPERACIONA': 'no label', 'TIPOPOSTOP': 'no label', });
lyr_clip_EDU_Campo_Quadra_P_12.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOCAMPOQ': 'TIPOCAMPOQ', 'OPERACIONA': 'OPERACIONA', 'SITUACAOFI': 'SITUACAOFI', });
lyr_clip_EDU_Campo_Quadra_P_12.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOCAMPOQ': 'TextEdit', 'OPERACIONA': 'TextEdit', 'SITUACAOFI': 'TextEdit', });
lyr_clip_EDU_Campo_Quadra_P_12.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOCAMPOQ': 'no label', 'OPERACIONA': 'no label', 'SITUACAOFI': 'no label', });
lyr_clip_VEG_Veg_Cultivada_A_0.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOLAVOUR': 'TIPOLAVOUR', 'FINALIDADE': 'FINALIDADE', 'CLASSIFICA': 'CLASSIFICA', 'ESPACAMENT': 'ESPACAMENT', 'ESPESSURAD': 'ESPESSURAD', 'ALTURAMEDI': 'ALTURAMEDI', 'CULTIVOPRE': 'CULTIVOPRE', 'NOMEABREV': 'NOMEABREV', });
lyr_clip_VEG_Veg_Cultivada_A_0.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOLAVOUR': 'TextEdit', 'FINALIDADE': 'TextEdit', 'CLASSIFICA': 'TextEdit', 'ESPACAMENT': 'TextEdit', 'ESPESSURAD': 'TextEdit', 'ALTURAMEDI': 'TextEdit', 'CULTIVOPRE': 'TextEdit', 'NOMEABREV': 'TextEdit', });
lyr_clip_VEG_Veg_Cultivada_A_0.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'GEOMETRIAA': 'no label', 'TIPOLAVOUR': 'no label', 'FINALIDADE': 'no label', 'CLASSIFICA': 'no label', 'ESPACAMENT': 'no label', 'ESPESSURAD': 'no label', 'ALTURAMEDI': 'no label', 'CULTIVOPRE': 'no label', 'NOMEABREV': 'no label', });
lyr_clip_REL_Elemento_Fisiografico_Natural_A_0.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOELEMNA': 'TIPOELEMNA', });
lyr_clip_REL_Elemento_Fisiografico_Natural_A_0.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOELEMNA': 'TextEdit', });
lyr_clip_REL_Elemento_Fisiografico_Natural_A_0.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOELEMNA': 'no label', });
lyr_clip_HID_Terreno_Sujeito_Inundacao_A_0.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'PERIODICID': 'PERIODICID', });
lyr_clip_HID_Ilha_A_8.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOILHA': 'TIPOILHA', });
lyr_clip_TRA_Trecho_Ferroviario_L_10.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'CODTRECHOF': 'CODTRECHOF', 'POSICAOREL': 'POSICAOREL', 'TIPOTRECHO': 'TIPOTRECHO', 'BITOLA': 'BITOLA', 'ELETRIFICA': 'ELETRIFICA', 'NRLINHAS': 'NRLINHAS', 'EMARRUAMEN': 'EMARRUAMEN', 'JURISDICAO': 'JURISDICAO', 'ADMINISTRA': 'ADMINISTRA', 'CONCESSION': 'CONCESSION', 'OPERACIONA': 'OPERACIONA', 'CARGASUPOR': 'CARGASUPOR', 'SITUACAOFI': 'SITUACAOFI', });
lyr_clip_VEG_Brejo_Pantano_A_3.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'ALTURAMEDI': 'ALTURAMEDI', 'CLASSIFICA': 'CLASSIFICA', 'TIPOBREJOP': 'TIPOBREJOP', 'DENSO': 'DENSO', });
lyr_clip_VEG_Campo_A_2.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOCAMPO': 'TIPOCAMPO', 'OCORRENCIA': 'OCORRENCIA', });
lyr_clip_VEG_Mangue_A_1.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'ALTURAMEDI': 'ALTURAMEDI', 'CLASSIFICA': 'CLASSIFICA', 'DENSO': 'DENSO', });
lyr_clip_ADM_Edif_Pub_Militar_P_15.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOEDIFMI': 'TIPOEDIFMI', 'TIPOUSOEDI': 'TIPOUSOEDI', 'SITUACAOFI': 'SITUACAOFI', 'OPERACIONA': 'OPERACIONA', 'MATCONSTR': 'MATCONSTR', });
lyr_clip_ASB_Cemiterio_P_13.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOCEMITE': 'TIPOCEMITE', 'DENOMINACA': 'DENOMINACA', });
lyr_clip_EDU_Edif_Ensino_P_18.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOCLASSE': 'TIPOCLASSE', 'OPERACIONA': 'OPERACIONA', 'MATCONSTR': 'MATCONSTR', 'SITUACAOFI': 'SITUACAOFI', });
lyr_clip_LOC_Nome_Local_P_19.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', });
lyr_clip_HID_Trecho_Massa_Dagua_A_7.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOTRECHO': 'TIPOTRECHO', 'SALINIDADE': 'SALINIDADE', 'REGIME': 'REGIME', });
lyr_clip_LOC_Vila_P_21.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOAGLOMR': 'TIPOAGLOMR', });
lyr_clip_VEG_Floresta_A_0.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'ALTURAMEDI': 'ALTURAMEDI', 'CLASSIFICA': 'CLASSIFICA', 'DENSO': 'DENSO', 'CARACTERIS': 'CARACTERIS', 'ESPECIEPRE': 'ESPECIEPRE', });
lyr_clip_LIM_Limite_Politico_Administrativo_L_1.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'COINCIDECO': 'COINCIDECO', 'EXTENSAO': 'EXTENSAO', 'OBSSITUACA': 'OBSSITUACA', 'TIPOLIMPOL': 'TIPOLIMPOL', });
lyr_clip_HID_Massa_Dagua_A_2.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOMASSAD': 'TIPOMASSAD', 'SALINIDADE': 'SALINIDADE', 'REGIME': 'REGIME', });
lyr_clip_HID_Trecho_Drenagem_L_3.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'DENTRODEPO': 'DENTRODEPO', 'COMPARTILH': 'COMPARTILH', 'EIXOPRINCI': 'EIXOPRINCI', 'CALADOMAX': 'CALADOMAX', 'LARGURAMED': 'LARGURAMED', 'VELOCIDADE': 'VELOCIDADE', 'PROFUNDIDA': 'PROFUNDIDA', 'COINCIDECO': 'COINCIDECO', 'NAVEGABILI': 'NAVEGABILI', 'REGIME': 'REGIME', });
lyr_clip_LOC_Cidade_P_4.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', });
lyr_clip_ASB_Area_Abast_Agua_A_5.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'GEOMETRIAA': 'GEOMETRIAA', });
lyr_clip_ECO_Ext_Mineral_P_6.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOSECAOC': 'TIPOSECAOC', 'OPERACIONA': 'OPERACIONA', 'SITUACAOFI': 'SITUACAOFI', 'TIPOEXTMIN': 'TIPOEXTMIN', 'TIPOPRODUT': 'TIPOPRODUT', 'TIPOPOCOMI': 'TIPOPOCOMI', 'ATIVIDADE': 'ATIVIDADE', });
lyr_clip_ENC_Area_Energia_Eletrica_A_7.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'GEOMETRIAA': 'GEOMETRIAA', });
lyr_clip_ENC_Trecho_Energia_L_8.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'EMDUTO': 'EMDUTO', 'TENSAOELET': 'TENSAOELET', 'NUMCIRCUIT': 'NUMCIRCUIT', 'ESPECIE': 'ESPECIE', 'POSICAOREL': 'POSICAOREL', 'OPERACIONA': 'OPERACIONA', 'SITUACAOFI': 'SITUACAOFI', });
lyr_clip_REL_Curva_Nivel_L_9.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'COTA': 'COTA', 'DEPRESSAO': 'DEPRESSAO', 'GEOMETRIAA': 'GEOMETRIAA', 'INDICE': 'INDICE', });
lyr_clip_REL_Elemento_Fisiografico_Natural_P_10.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOELEMNA': 'TIPOELEMNA', });
lyr_clip_REL_Ponto_Cotado_Altimetrico_P_11.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'GEOMETRIAA': 'GEOMETRIAA', 'COTA': 'COTA', 'COTACOMPRO': 'COTACOMPRO', });
lyr_clip_TRA_Arruamento_L_12.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'NRFAIXAS': 'NRFAIXAS', 'CANTEIRODI': 'CANTEIRODI', 'OPERACIONA': 'OPERACIONA', 'SITUACAOFI': 'SITUACAOFI', 'REVESTIMEN': 'REVESTIMEN', 'TRAFEGO': 'TRAFEGO', });
lyr_clip_TRA_Atracadouro_L_13.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', 'TIPOATRACA': 'TIPOATRACA', 'OPERACIONA': 'OPERACIONA', 'SITUACAOFI': 'SITUACAOFI', 'ADMINISTRA': 'ADMINISTRA', 'MATCONSTR': 'MATCONSTR', });
lyr_clip_TRA_Ponte_L_14.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'GEOMETRIAA': 'GEOMETRIAA', 'NOMEABREV': 'NOMEABREV', 'TIPOPONTE': 'TIPOPONTE', 'MODALUSO': 'MODALUSO', 'SITUACAOFI': 'SITUACAOFI', 'OPERACIONA': 'OPERACIONA', 'MATCONSTR': 'MATCONSTR', 'VAOLIVREHO': 'VAOLIVREHO', 'VAOVERTICA': 'VAOVERTICA', 'CARGASUPOR': 'CARGASUPOR', 'NRPISTAS': 'NRPISTAS', 'NRFAIXAS': 'NRFAIXAS', 'EXTENSAO': 'EXTENSAO', 'LARGURA': 'LARGURA', 'POSICAOPIS': 'POSICAOPIS', });
lyr_clip_TRA_Trecho_Rodoviario_L_15.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'GEOMETRIAA': 'GEOMETRIAA', 'CODTRECHOR': 'CODTRECHOR', 'TIPOTRECHO': 'TIPOTRECHO', 'JURISDICAO': 'JURISDICAO', 'ADMINISTRA': 'ADMINISTRA', 'CONCESSION': 'CONCESSION', 'REVESTIMEN': 'REVESTIMEN', 'OPERACIONA': 'OPERACIONA', 'SITUACAOFI': 'SITUACAOFI', 'NRPISTAS': 'NRPISTAS', 'NRFAIXAS': 'NRFAIXAS', 'TRAFEGO': 'TRAFEGO', 'CANTEIRODI': 'CANTEIRODI', 'CAPACCARGA': 'CAPACCARGA', });
lyr_clip_HID_Terreno_Sujeito_Inundacao_A_0.set('fieldImages', {'ID_OBJETO': '', 'NOME': '', 'NOMEABREV': '', 'GEOMETRIAA': '', 'PERIODICID': '', });
lyr_clip_HID_Ilha_A_8.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOILHA': 'TextEdit', });
lyr_clip_TRA_Trecho_Ferroviario_L_10.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'CODTRECHOF': 'TextEdit', 'POSICAOREL': 'TextEdit', 'TIPOTRECHO': 'TextEdit', 'BITOLA': 'TextEdit', 'ELETRIFICA': 'TextEdit', 'NRLINHAS': 'TextEdit', 'EMARRUAMEN': 'TextEdit', 'JURISDICAO': 'TextEdit', 'ADMINISTRA': 'TextEdit', 'CONCESSION': 'TextEdit', 'OPERACIONA': 'TextEdit', 'CARGASUPOR': 'TextEdit', 'SITUACAOFI': 'TextEdit', });
lyr_clip_VEG_Brejo_Pantano_A_3.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'ALTURAMEDI': 'TextEdit', 'CLASSIFICA': 'TextEdit', 'TIPOBREJOP': 'TextEdit', 'DENSO': 'TextEdit', });
lyr_clip_VEG_Campo_A_2.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOCAMPO': 'TextEdit', 'OCORRENCIA': 'TextEdit', });
lyr_clip_VEG_Mangue_A_1.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'ALTURAMEDI': 'TextEdit', 'CLASSIFICA': 'TextEdit', 'DENSO': 'TextEdit', });
lyr_clip_ADM_Edif_Pub_Militar_P_15.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOEDIFMI': 'TextEdit', 'TIPOUSOEDI': 'TextEdit', 'SITUACAOFI': 'TextEdit', 'OPERACIONA': 'TextEdit', 'MATCONSTR': 'TextEdit', });
lyr_clip_ASB_Cemiterio_P_13.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOCEMITE': 'TextEdit', 'DENOMINACA': 'TextEdit', });
lyr_clip_EDU_Edif_Ensino_P_18.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOCLASSE': 'TextEdit', 'OPERACIONA': 'TextEdit', 'MATCONSTR': 'TextEdit', 'SITUACAOFI': 'TextEdit', });
lyr_clip_LOC_Nome_Local_P_19.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', });
lyr_clip_HID_Trecho_Massa_Dagua_A_7.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOTRECHO': 'TextEdit', 'SALINIDADE': 'TextEdit', 'REGIME': 'TextEdit', });
lyr_clip_LOC_Vila_P_21.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOAGLOMR': 'TextEdit', });
lyr_clip_LOC_Area_Edificada_A_6.set('fieldAliases', {'ID_OBJETO': 'ID_OBJETO', 'NOME': 'NOME', 'NOMEABREV': 'NOMEABREV', 'GEOMETRIAA': 'GEOMETRIAA', });
lyr_clip_VEG_Floresta_A_0.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'ALTURAMEDI': 'TextEdit', 'CLASSIFICA': 'TextEdit', 'DENSO': 'TextEdit', 'CARACTERIS': 'TextEdit', 'ESPECIEPRE': 'TextEdit', });
lyr_clip_LIM_Limite_Politico_Administrativo_L_1.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'COINCIDECO': 'TextEdit', 'EXTENSAO': 'TextEdit', 'OBSSITUACA': 'TextEdit', 'TIPOLIMPOL': 'TextEdit', });
lyr_clip_HID_Massa_Dagua_A_2.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOMASSAD': 'TextEdit', 'SALINIDADE': 'TextEdit', 'REGIME': 'TextEdit', });
lyr_clip_HID_Trecho_Drenagem_L_3.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'DENTRODEPO': 'TextEdit', 'COMPARTILH': 'TextEdit', 'EIXOPRINCI': 'TextEdit', 'CALADOMAX': 'TextEdit', 'LARGURAMED': 'TextEdit', 'VELOCIDADE': 'TextEdit', 'PROFUNDIDA': 'TextEdit', 'COINCIDECO': 'TextEdit', 'NAVEGABILI': 'TextEdit', 'REGIME': 'TextEdit', });
lyr_clip_LOC_Cidade_P_4.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', });
lyr_clip_ASB_Area_Abast_Agua_A_5.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'GEOMETRIAA': 'TextEdit', });
lyr_clip_ECO_Ext_Mineral_P_6.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOSECAOC': 'TextEdit', 'OPERACIONA': 'TextEdit', 'SITUACAOFI': 'TextEdit', 'TIPOEXTMIN': 'TextEdit', 'TIPOPRODUT': 'TextEdit', 'TIPOPOCOMI': 'TextEdit', 'ATIVIDADE': 'TextEdit', });
lyr_clip_ENC_Area_Energia_Eletrica_A_7.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'GEOMETRIAA': 'TextEdit', });
lyr_clip_ENC_Trecho_Energia_L_8.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'EMDUTO': 'TextEdit', 'TENSAOELET': 'TextEdit', 'NUMCIRCUIT': 'TextEdit', 'ESPECIE': 'TextEdit', 'POSICAOREL': 'TextEdit', 'OPERACIONA': 'TextEdit', 'SITUACAOFI': 'TextEdit', });
lyr_clip_REL_Curva_Nivel_L_9.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'COTA': 'TextEdit', 'DEPRESSAO': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'INDICE': 'TextEdit', });
lyr_clip_REL_Elemento_Fisiografico_Natural_P_10.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOELEMNA': 'TextEdit', });
lyr_clip_REL_Ponto_Cotado_Altimetrico_P_11.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'COTA': 'TextEdit', 'COTACOMPRO': 'TextEdit', });
lyr_clip_TRA_Arruamento_L_12.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'NRFAIXAS': 'TextEdit', 'CANTEIRODI': 'TextEdit', 'OPERACIONA': 'TextEdit', 'SITUACAOFI': 'TextEdit', 'REVESTIMEN': 'TextEdit', 'TRAFEGO': 'TextEdit', });
lyr_clip_TRA_Atracadouro_L_13.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'TIPOATRACA': 'TextEdit', 'OPERACIONA': 'TextEdit', 'SITUACAOFI': 'TextEdit', 'ADMINISTRA': 'TextEdit', 'MATCONSTR': 'TextEdit', });
lyr_clip_TRA_Ponte_L_14.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'NOMEABREV': 'TextEdit', 'TIPOPONTE': 'TextEdit', 'MODALUSO': 'TextEdit', 'SITUACAOFI': 'TextEdit', 'OPERACIONA': 'TextEdit', 'MATCONSTR': 'TextEdit', 'VAOLIVREHO': 'TextEdit', 'VAOVERTICA': 'TextEdit', 'CARGASUPOR': 'TextEdit', 'NRPISTAS': 'TextEdit', 'NRFAIXAS': 'TextEdit', 'EXTENSAO': 'TextEdit', 'LARGURA': 'TextEdit', 'POSICAOPIS': 'TextEdit', });
lyr_clip_TRA_Trecho_Rodoviario_L_15.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'GEOMETRIAA': 'TextEdit', 'CODTRECHOR': 'TextEdit', 'TIPOTRECHO': 'TextEdit', 'JURISDICAO': 'TextEdit', 'ADMINISTRA': 'TextEdit', 'CONCESSION': 'TextEdit', 'REVESTIMEN': 'TextEdit', 'OPERACIONA': 'TextEdit', 'SITUACAOFI': 'TextEdit', 'NRPISTAS': 'TextEdit', 'NRFAIXAS': 'TextEdit', 'TRAFEGO': 'TextEdit', 'CANTEIRODI': 'TextEdit', 'CAPACCARGA': 'TextEdit', });
lyr_clip_HID_Terreno_Sujeito_Inundacao_A_0.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'PERIODICID': 'no label', });
lyr_clip_HID_Ilha_A_8.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOILHA': 'no label', });
lyr_clip_TRA_Trecho_Ferroviario_L_10.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'CODTRECHOF': 'no label', 'POSICAOREL': 'no label', 'TIPOTRECHO': 'no label', 'BITOLA': 'no label', 'ELETRIFICA': 'no label', 'NRLINHAS': 'no label', 'EMARRUAMEN': 'no label', 'JURISDICAO': 'no label', 'ADMINISTRA': 'no label', 'CONCESSION': 'no label', 'OPERACIONA': 'no label', 'CARGASUPOR': 'no label', 'SITUACAOFI': 'no label', });
lyr_clip_VEG_Brejo_Pantano_A_3.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'ALTURAMEDI': 'no label', 'CLASSIFICA': 'no label', 'TIPOBREJOP': 'no label', 'DENSO': 'no label', });
lyr_clip_VEG_Campo_A_2.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOCAMPO': 'no label', 'OCORRENCIA': 'no label', });
lyr_clip_VEG_Mangue_A_1.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'ALTURAMEDI': 'no label', 'CLASSIFICA': 'no label', 'DENSO': 'no label', });
lyr_clip_ADM_Edif_Pub_Militar_P_15.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOEDIFMI': 'no label', 'TIPOUSOEDI': 'no label', 'SITUACAOFI': 'no label', 'OPERACIONA': 'no label', 'MATCONSTR': 'no label', });
lyr_clip_ASB_Cemiterio_P_13.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOCEMITE': 'no label', 'DENOMINACA': 'no label', });
lyr_clip_EDU_Edif_Ensino_P_18.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOCLASSE': 'no label', 'OPERACIONA': 'no label', 'MATCONSTR': 'no label', 'SITUACAOFI': 'no label', });
lyr_clip_LOC_Nome_Local_P_19.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', });
lyr_clip_HID_Trecho_Massa_Dagua_A_7.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOTRECHO': 'no label', 'SALINIDADE': 'no label', 'REGIME': 'no label', });
lyr_clip_LOC_Vila_P_21.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOAGLOMR': 'no label', });
lyr_clip_LOC_Area_Edificada_A_6.set('fieldImages', {'ID_OBJETO': 'TextEdit', 'NOME': 'TextEdit', 'NOMEABREV': 'TextEdit', 'GEOMETRIAA': 'TextEdit', });
lyr_clip_VEG_Floresta_A_0.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'ALTURAMEDI': 'no label', 'CLASSIFICA': 'no label', 'DENSO': 'no label', 'CARACTERIS': 'no label', 'ESPECIEPRE': 'no label', });
lyr_clip_LIM_Limite_Politico_Administrativo_L_1.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'COINCIDECO': 'no label', 'EXTENSAO': 'no label', 'OBSSITUACA': 'no label', 'TIPOLIMPOL': 'no label', });
lyr_clip_HID_Massa_Dagua_A_2.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'inline label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOMASSAD': 'no label', 'SALINIDADE': 'no label', 'REGIME': 'no label', });
lyr_clip_HID_Trecho_Drenagem_L_3.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'inline label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'DENTRODEPO': 'no label', 'COMPARTILH': 'no label', 'EIXOPRINCI': 'no label', 'CALADOMAX': 'no label', 'LARGURAMED': 'no label', 'VELOCIDADE': 'no label', 'PROFUNDIDA': 'no label', 'COINCIDECO': 'no label', 'NAVEGABILI': 'no label', 'REGIME': 'no label', });
lyr_clip_LOC_Cidade_P_4.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'inline label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', });
lyr_clip_ASB_Area_Abast_Agua_A_5.set('fieldLabels', {'ID_OBJETO': 'no label', 'GEOMETRIAA': 'no label', });
lyr_clip_ECO_Ext_Mineral_P_6.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOSECAOC': 'no label', 'OPERACIONA': 'no label', 'SITUACAOFI': 'no label', 'TIPOEXTMIN': 'no label', 'TIPOPRODUT': 'no label', 'TIPOPOCOMI': 'no label', 'ATIVIDADE': 'no label', });
lyr_clip_ENC_Area_Energia_Eletrica_A_7.set('fieldLabels', {'ID_OBJETO': 'no label', 'GEOMETRIAA': 'no label', });
lyr_clip_ENC_Trecho_Energia_L_8.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'EMDUTO': 'no label', 'TENSAOELET': 'no label', 'NUMCIRCUIT': 'no label', 'ESPECIE': 'no label', 'POSICAOREL': 'no label', 'OPERACIONA': 'no label', 'SITUACAOFI': 'no label', });
lyr_clip_REL_Curva_Nivel_L_9.set('fieldLabels', {'ID_OBJETO': 'no label', 'COTA': 'inline label', 'DEPRESSAO': 'no label', 'GEOMETRIAA': 'no label', 'INDICE': 'no label', });
lyr_clip_REL_Elemento_Fisiografico_Natural_P_10.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'inline label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOELEMNA': 'no label', });
lyr_clip_REL_Ponto_Cotado_Altimetrico_P_11.set('fieldLabels', {'ID_OBJETO': 'no label', 'GEOMETRIAA': 'no label', 'COTA': 'inline label', 'COTACOMPRO': 'no label', });
lyr_clip_TRA_Arruamento_L_12.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'NRFAIXAS': 'no label', 'CANTEIRODI': 'no label', 'OPERACIONA': 'no label', 'SITUACAOFI': 'no label', 'REVESTIMEN': 'no label', 'TRAFEGO': 'no label', });
lyr_clip_TRA_Atracadouro_L_13.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', 'TIPOATRACA': 'no label', 'OPERACIONA': 'no label', 'SITUACAOFI': 'no label', 'ADMINISTRA': 'no label', 'MATCONSTR': 'no label', });
lyr_clip_TRA_Ponte_L_14.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'GEOMETRIAA': 'no label', 'NOMEABREV': 'no label', 'TIPOPONTE': 'no label', 'MODALUSO': 'no label', 'SITUACAOFI': 'no label', 'OPERACIONA': 'no label', 'MATCONSTR': 'no label', 'VAOLIVREHO': 'no label', 'VAOVERTICA': 'no label', 'CARGASUPOR': 'no label', 'NRPISTAS': 'no label', 'NRFAIXAS': 'no label', 'EXTENSAO': 'no label', 'LARGURA': 'no label', 'POSICAOPIS': 'no label', });
lyr_clip_TRA_Trecho_Rodoviario_L_15.set('fieldLabels', {'ID_OBJETO': 'no label', 'GEOMETRIAA': 'no label', 'CODTRECHOR': 'inline label', 'TIPOTRECHO': 'inline label', 'JURISDICAO': 'no label', 'ADMINISTRA': 'no label', 'CONCESSION': 'no label', 'REVESTIMEN': 'inline label', 'OPERACIONA': 'no label', 'SITUACAOFI': 'no label', 'NRPISTAS': 'no label', 'NRFAIXAS': 'no label', 'TRAFEGO': 'no label', 'CANTEIRODI': 'no label', 'CAPACCARGA': 'no label', });
lyr_clip_LOC_Area_Edificada_A_6.set('fieldLabels', {'ID_OBJETO': 'no label', 'NOME': 'no label', 'NOMEABREV': 'no label', 'GEOMETRIAA': 'no label', });
lyr_clip_LOC_Area_Edificada_A_6.set.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});