function elempFunction(feature) {
  var nome = feature.get('nome');

 
  nome = nome.toUpperCase();

  
  var palavras = nome.split(' ');
  var texto_quebrado = '';
  var linha = '';
  for (var i = 0; i < palavras.length; i++) {
    if ((linha + palavras[i]).length <= 12) {
      linha += palavras[i] + ' ';
    } else {
      texto_quebrado += linha.trim() + '\n';
      linha = palavras[i] + ' ';
    }
  }
  texto_quebrado += linha.trim();

  var elemp = new ol.style.Style({
    image: new ol.style.Circle({
      radius: 0,
      fill: new ol.style.Fill({
        color: '#000000' 
      }),
      stroke: new ol.style.Stroke({
        color: '#000000', 
        width: 0 
      })
    }),
    text: new ol.style.Text({
      text: texto_quebrado, 
      font: '8px Arial', 
      offsetY: 0, 
      fill: new ol.style.Fill({
        color: '#000000' 
      }),
      stroke: new ol.style.Stroke({
        color: 'white', 
        width: 1 
      }),
      textAlign: 'center', 
      textBaseline: 'top', 
      overflow: true, 
      wordWrap: true, 
      maxLines: 2 
    })
  });

  return elemp;
}

