
var pistapouso = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#F00000'
  }),
  stroke: new ol.style.Stroke({
    color: '#000000', 
    width: 1 
  })
});

function pistapousoFunction(feature) {
  return [pistapouso];
}
