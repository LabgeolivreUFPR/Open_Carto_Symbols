
function quebrarTexto(texto, tamanhoMaximo) {
  var palavras = texto.split(' ');
  var textoQuebrado = '';
  var linha = '';
  for (var i = 0; i < palavras.length; i++) {
    if ((linha + palavras[i]).length <= tamanhoMaximo) {
      linha += palavras[i] + ' ';
    } else {
      textoQuebrado += linha.trim() + '\n';
      linha = palavras[i] + ' ';
    }
  }
  textoQuebrado += linha.trim();
  return textoQuebrado.trim();
}

function mineralFunction(feature) {
  var nome = feature.get('nome');
  var textoQuebrado = quebrarTexto(nome, 20);

  var mineral = new ol.style.Style({
    image: new ol.style.Icon({
      src: 'mineral.svg', 
      imgSize: [10, 10] 
    }),
    text: new ol.style.Text({
      text: textoQuebrado, 
      font: '9px Century Gothic',
      offsetX: 0,
      offsetY: 0, 
      fill: new ol.style.Fill({
        color: 'black' 
      }),
      stroke: new ol.style.Stroke({
        color: 'white', 
        width: 2
      }),
      overflow: true, 
      maxAngle: 0, 
      textAlign: 'center', 
      textBaseline: 'top', 
      offsetY: 10 
    })
  });

  return mineral;
}
