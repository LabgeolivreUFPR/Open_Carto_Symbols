var leitoNatural = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#000000' 
  }),
  stroke: new ol.style.Stroke({
    color: '#000000', 
    width: 1 
  })
});

var pavimentado = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#DC0000'  
  }),
  stroke: new ol.style.Stroke({
    color: '#DC0000', 
    width: 2 
  })
});
function rodoviaFunction(feature) {
 
  var revestimento = feature.get('revestimento');

  
  if (revestimento === 'Leito natural') {
    return [leitoNatural];
  } else if (revestimento === 'Pavimentado') {
    return [pavimentado];
  } else {
    return [];
  }
}
