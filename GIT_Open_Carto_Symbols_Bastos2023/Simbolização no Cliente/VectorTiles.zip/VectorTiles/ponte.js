
var ponte = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#F00000'
  }),
  stroke: new ol.style.Stroke({
    color: '#000000', 
    width: 2 
  })
});

function ponteFunction(feature) {
  return [ponte]; 
}
