
var arruamento = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#000000'
  }),
  stroke: new ol.style.Stroke({
    color: '#000000', 
    width: 0.3 
  })
});

function arruamentoFunction(feature) {
  return [arruamento]; 
}
