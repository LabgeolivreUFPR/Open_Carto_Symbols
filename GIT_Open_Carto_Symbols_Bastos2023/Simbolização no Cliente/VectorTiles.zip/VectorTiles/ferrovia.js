var ferrovia = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#E1FFF0'
  }),
  stroke: new ol.style.Stroke({
    color: '#000', 
    width: 1 
  })
});

function ferroviaFunction(feature) {
  return [ferrovia]; 
}
