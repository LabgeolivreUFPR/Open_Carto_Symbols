
var temporario = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#045DA3' 
  }),
  stroke: new ol.style.Stroke({
    color: '#045DA3', 
    width: 1,
    lineDash: [8, 3, 1, 3]
  })
});

var permanente = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#045DA3' 
  }),
  stroke: new ol.style.Stroke({
    color: '#045DA3', 
    width: 2 
  })
});

var estiloTexto = new ol.style.Style({
  text: new ol.style.Text({
    text: function (feature) {
      
      return feature.get('nome');
    },
    font: '12px Calibri,sans-serif',
    fill: new ol.style.Fill({
      color: '#045DA3' 
    }),
    stroke: new ol.style.Stroke({
      color: '#FFFFFF', 
      width: 2 
    }),
    textAlign: 'center',
    textBaseline: 'middle',
    placement: 'line', 
    maxAngle: Math.PI / 6 
  })
});

function hidrografiaFunction(feature) {
  
  var regime = feature.get('regime');

  
  if (regime === 'Temporário') {
    return [temporario, estiloTexto];
  } else if (regime === 'Permanente') {
    return [permanente, estiloTexto];
  } else {
    
    return [estiloTexto];
  }
}


