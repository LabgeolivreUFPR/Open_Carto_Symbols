
function massaFunction(feature) {
  var nome = feature.get('nome'); 

  var estilo = new ol.style.Style({
    fill: new ol.style.Fill({
      color: '#91d1f5'
    }),
    stroke: new ol.style.Stroke({
      color: '#045da3',
      width: 0.5
    }),
    text: new ol.style.Text({
      text: nome, 
      font: 'italic bold 11px Century Gothic', 
      fill: new ol.style.Fill({
        color: '#045da3' 
      }),
      stroke: new ol.style.Stroke({
        color: 'white', 
        width: 1
      }),
      textAlign: 'center', 
      textBaseline: 'middle' 
    })
  });

  return [estilo]; 
}
