
var trechoener = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#000000'
  }),
  stroke: new ol.style.Stroke({
    color: '#000000', 
    width: 0.5, 
    lineDash: [15,5,1,5] 
  })
});

function trechoenerFunction(feature) {
  return [trechoener]; 
}
