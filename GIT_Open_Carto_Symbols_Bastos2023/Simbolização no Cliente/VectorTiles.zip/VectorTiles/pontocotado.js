
function pontocotadoFunction(feature) {
  var cota = feature.get('');
  var pontocotado = new ol.style.Style({
    image: new ol.style.Circle({
      radius: 1, 
      fill: new ol.style.Fill({
        color: '#705714' 
      }),
      stroke: new ol.style.Stroke({
        color: '#705714', 
        width: 0 
      })
    }),
    text: new ol.style.Text({
      text: cota, 
      font: '9px Century Gothic', 
      offsetY: 10, 
      fill: new ol.style.Fill({
        color: '#705714' 
      }),
      stroke: new ol.style.Stroke({
        color: 'white', 
        width: 1
      }),
      textAlign: 'center', 
      textBaseline: 'top' 
    })
  });

  return pontocotado;
}
