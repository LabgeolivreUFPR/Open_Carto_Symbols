var limite = new ol.style.Style({
  fill: new ol.style.Fill({
    color: '#000000'
  }),
  stroke: new ol.style.Stroke({
    color: '#000000', 
    width: 1, 
    lineDash: [10,5,3,5] )
  })
});

function limiteFunction(feature) {
  return [limite]; 
}
