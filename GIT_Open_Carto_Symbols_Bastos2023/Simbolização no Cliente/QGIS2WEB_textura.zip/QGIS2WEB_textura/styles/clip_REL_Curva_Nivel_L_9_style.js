var size = 0;
var placement = 'point';
function categories_clip_REL_Curva_Nivel_L_9(feature, value, size, resolution, labelText,
                       labelFont, labelFill, bufferColor, bufferWidth,
                       placement) {
                switch(value.toString()) {case 'Mestra':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: '#705714', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.8}),
        text: createTextStyle2(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Normal':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: '#705714', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.5})
    })];
                    break;}};

var style_clip_REL_Curva_Nivel_L_9 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("INDICE");
    var labelText = "";
    size = 0;
    var labelFont = "italic bold 9px \'Open Sans\', sans-serif";
    var labelFill = "#705714";
    var bufferColor = "#FFFFFF";
    var bufferWidth = 1;
    var placement = 'line';
     if (feature.get("COTA") > 0) {
        labelText = String(feature.get("COTA"));
    }
    
var style2 = categories_clip_REL_Curva_Nivel_L_9(feature, value, size, resolution, labelText,
                          labelFont, labelFill, bufferColor,
                          bufferWidth, placement);

    return style2;
};
var createTextStyle2 = function(feature, resolution, labelText, labelFont,
                               labelFill, placement, bufferColor,
                               bufferWidth) {

    if (feature.hide || !labelText) {
        return; 
    } 

    if (bufferWidth == 0) {
        var bufferStyle = null;
    } else {
        var bufferStyle = new ol.style.Stroke({
            color: bufferColor,
            width: bufferWidth
        })
    }
    
    var textStyle2 = new ol.style.Text({
        font: labelFont,
        text: labelText,
        textBaseline: "middle",
        textAlign: "left",
        placement: placement,
        overflow: 'true',
        maxAngle: (Math.PI / 4),
        fill: new ol.style.Fill({
          color: labelFill
        }),
        stroke: bufferStyle
    });
    return textStyle2;
};
