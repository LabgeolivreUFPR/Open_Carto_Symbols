var size = 0;
var placement = 'point';

var style_clip_ASB_Cemiterio_P_13 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = ""
    var labelText = "";
    size = 0;
    var labelFont = "9.0px \'MS Shell Dlg 2\', Century Gothic";
    var labelFill = "#000000";
    var bufferColor = "#FFFFFF";
    var bufferWidth = 2;
    var textAlign = "center";
    var offsetX = 8;
    var offsetY = 3;
    var placement = 'point';
    if (feature.get("NOME") !== null) {
        labelText = String(feature.get("NOME"));
    }
    var style = [ new ol.style.Style({
        image: new ol.style.Icon({
                  imgSize: [20, 20],
                  scale: 0.6,
                  anchor: [6, 6],
                  anchorXUnits: "pixels",
                  anchorYUnits: "pixels",
                  rotation: 0.0,
                  src: "styles/CEMITERIO.svg"
            }),
        text: createTextStyle_cem(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];

    return style;
};
var createTextStyle_cem = function(feature, resolution, labelText, labelFont,
                               labelFill, placement, bufferColor,
                               bufferWidth) {

    if (feature.hide || !labelText) {
        return; 
    } 

    if (bufferWidth == 0) {
        var bufferStyle = null;
    } else {
        var bufferStyle = new ol.style.Stroke({
            color: bufferColor,
            width: bufferWidth
        })
    }
    
    var maxTextLength = 20; // Define o comprimento máximo do texto em cada linha
    var lines = [];
    var currentLine = '';
    var words = labelText.split(' ');

    for (var i = 0; i < words.length; i++) {
        if (currentLine.length + words[i].length <= maxTextLength) {
            currentLine += words[i] + ' ';
        } else {
            lines.push(currentLine.trim());
            currentLine = words[i] + ' ';
        }
    }

    if (currentLine.trim() !== '') {
        lines.push(currentLine.trim());
    }

    var textStyle_cem = new ol.style.Text({
        font: labelFont,
        text: lines.join('\n'), // Junta as linhas com uma quebra de linha entre elas
        textAlign: "center",
        offsetY: 25,
        placement: placement,
        fill: new ol.style.Fill({
          color: labelFill
        }),
        stroke: bufferStyle
    });

    return textStyle_cem;
};
