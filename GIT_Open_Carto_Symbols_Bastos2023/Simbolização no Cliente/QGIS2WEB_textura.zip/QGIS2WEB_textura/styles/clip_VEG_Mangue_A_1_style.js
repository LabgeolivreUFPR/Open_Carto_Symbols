var size = 0;
var placement = 'point';

function createPointStyle() {
    return new ol.style.Style({
        image: new ol.style.Circle({
            radius: 5,
            fill: new ol.style.Fill({color: 'rgba(112,87,20,1.0)'}),
            stroke: new ol.style.Stroke({color: '#000', width: 1})
        })
    });
}


var style_clip_VEG_Mangue_A_1 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = "";
    var labelText = "";
    size = 0;
    var labelFont = "13.0px \'Open Sans\', sans-serif";
    var labelFill = "#323232";
    var bufferColor = "";
    var bufferWidth = 0;
    var textAlign = "left";
    var offsetX = 8;
    var offsetY = 3;
    var placement = 'point';


    var pointStyle = createPointStyle();


    var cnv = document.createElement('canvas');
    var ctx = cnv.getContext('2d');
    var img = new Image();
    img.src = 'https://github.com/Labgeolivre-UFPR/Open_Carto_Symbols/blob/master/GIT_Open_Carto_Symbols_Bastos2023/PNG/VEG_Mangue.png?raw=true'; 
    img.onload = function() {
        var pattern = ctx.createPattern(img, 'repeat');
        ctx.fillStyle = pattern;
        ctx.fillRect(0, 0, cnv.width, cnv.height);

        var style = [new ol.style.Style({
            fill: new ol.style.Fill({color: pattern}),
            text: createTextStyle(feature, resolution, labelText, labelFont,
                                  labelFill, placement, bufferColor,
                                  bufferWidth, textAlign, offsetX, offsetY)
        })];

        feature.setStyle(style);
    };

    return style;
};

var layer = new ol.layer.Vector({
    source: source,
    style: style_clip_VEG_Mangue_A_1
});