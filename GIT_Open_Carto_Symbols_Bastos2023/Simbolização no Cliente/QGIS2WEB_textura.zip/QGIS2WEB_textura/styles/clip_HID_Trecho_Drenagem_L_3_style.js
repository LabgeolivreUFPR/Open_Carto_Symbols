var size = 0;
var placement = 'point';
function categories_clip_HID_Trecho_Drenagem_L_3(feature, value, size, resolution, labelText,
                       labelFont, labelFill, bufferColor, bufferWidth,
                       placement) {
                switch(value.toString()) {case 'Permanente':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: '#045da3', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 1.5}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Temporário':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: '#045da3', lineDash: [8,3,1,3], lineCap: 'square', lineJoin: 'bevel', width: 1.2}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;}};

var style_clip_HID_Trecho_Drenagem_L_3 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("REGIME");
    var labelText = "";
    size = 0;
    var labelFont = "italic bold 12.0px \'MS Shell Dlg 2\', Century Gothic";
    var labelFill = "#045da3";
    var bufferColor = "#FFFFFF";
    var bufferWidth = 2;
    var placement = 'line';
    if (feature.get("NOME") !== null) {
        labelText = String(feature.get("NOME"));
    }
    
var style = categories_clip_HID_Trecho_Drenagem_L_3(feature, value, size, resolution, labelText,
                          labelFont, labelFill, bufferColor,
                          bufferWidth, placement);

    return style;
};
var createTextStyle = function(feature, resolution, labelText, labelFont,
                               labelFill, placement, bufferColor,
                               bufferWidth) {

    if (feature.hide || !labelText) {
        return; 
    } 

    if (bufferWidth == 0) {
        var bufferStyle = null;
    } else {
        var bufferStyle = new ol.style.Stroke({
            color: bufferColor,
            width: bufferWidth
        })
    }
    
    var textStyle = new ol.style.Text({
        font: labelFont,
        text: labelText,
        textBaseline: "bottom",
        textAlign: "center",
        placement: placement,
        overflow: 'true',
        maxAngle: (Math.PI / 6),
        fill: new ol.style.Fill({
          color: labelFill
        }),
        stroke: bufferStyle
    });
    return textStyle;
};